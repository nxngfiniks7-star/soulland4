package com.soulland.mod;

import net.minecraftforge.fml.client.registry.ClientRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        ClientRegistry.registerKeyBinding(ClientHandler.CAST);
        ClientRegistry.registerKeyBinding(ClientHandler.CYCLE);
        ClientRegistry.registerKeyBinding(ClientHandler.RELEASE);
    }
}
