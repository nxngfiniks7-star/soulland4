package com.soulland.mod;

import java.util.Random;
import java.util.UUID;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = SoulLand.MODID)
public class CommonEvents {
    private static final UUID BEAST_HP = UUID.fromString("5b1c2f0e-7d3a-4e6b-8f21-0c9a4d7e3a55");
    private static final UUID BEAST_ATK = UUID.fromString("a41e9d73-2b5c-4c88-9e10-3f6b7a8c2d41");

    private static int tierFor(float h) {
        return h <= 20 ? 0 : h <= 40 ? 1 : h <= 100 ? 2 : h <= 200 ? 3 : 4;
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != Side.SERVER) return;
        EntityPlayerMP p = (EntityPlayerMP) e.player;
        if (SoulData.getSoul(p) == 0) return;
        if (p.ticksExisted % 100 == 0) SoulData.syncVisual(p);
        if (p.ticksExisted % 20 != 0) return;
        int max = SoulData.maxMana(p), m = SoulData.getMana(p);
        if (m < max) {
            SoulData.setMana(p, Math.min(max, m + 3 + SoulData.getLevel(p) / 6));
            SoulData.sync(p);
        }
    }

    @SubscribeEvent
    public static void kill(LivingDeathEvent e) {
        if (!(e.getSource().getTrueSource() instanceof EntityPlayerMP)) return;
        EntityPlayerMP p = (EntityPlayerMP) e.getSource().getTrueSource();
        EntityLivingBase mob = e.getEntityLiving();
        if (SoulData.getSoul(p) == 0 || mob instanceof EntityPlayer) return;
        int gain = Math.max(3, (int) mob.getMaxHealth());
        int[] beast = mob.getEntityData().getIntArray("sl_tiers");
        if (beast.length > 0) gain *= (beast.length + 1);
        SoulData.addExp(p, gain);
    }

    /** สัตว์วิญญาณ: มอนสเตอร์ที่เกิดมาพร้อมวงแหวน (แกร่งขึ้น และดรอปวงแหวนแน่นอน) */
    @SubscribeEvent
    public static void join(EntityJoinWorldEvent e) {
        Entity en = e.getEntity();
        if (e.getWorld().isRemote || !(en instanceof EntityLiving) || !(en instanceof IMob)) return;
        NBTTagCompound d = en.getEntityData();
        if (d.getBoolean("sl_checked")) return;
        d.setBoolean("sl_checked", true);
        EntityLiving mob = (EntityLiving) en;
        if (!mob.isNonBoss()) return;
        Random r = e.getWorld().rand;
        if (r.nextDouble() >= 0.15) return;
        int base = tierFor(mob.getMaxHealth());
        int n = 1 + r.nextInt(3);
        int[] tiers = new int[n];
        for (int i = 0; i < n; i++) tiers[i] = Math.min(4, base + (i >= 1 && r.nextBoolean() ? 1 : 0));
        d.setIntArray("sl_tiers", tiers);
        IAttributeInstance hp = mob.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH);
        if (hp != null) hp.applyModifier(new AttributeModifier(BEAST_HP, "soulland.beast_hp", 10.0 * n, 0));
        IAttributeInstance atk = mob.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE);
        if (atk != null) atk.applyModifier(new AttributeModifier(BEAST_ATK, "soulland.beast_atk", 1.5 * n, 0));
        mob.setHealth(mob.getMaxHealth());
    }

    @SubscribeEvent
    public static void track(PlayerEvent.StartTracking e) {
        Entity t = e.getTarget();
        if (!(t instanceof EntityLiving) || !(t instanceof IMob) || !(e.getEntityPlayer() instanceof EntityPlayerMP)) return;
        int[] tiers = t.getEntityData().getIntArray("sl_tiers");
        NetworkHandler.CHANNEL.sendTo(new PacketMobRings(t.getEntityId(), tiers), (EntityPlayerMP) e.getEntityPlayer());
    }

    @SubscribeEvent
    public static void drops(LivingDropsEvent e) {
        if (!(e.getSource().getTrueSource() instanceof EntityPlayer)) return;
        EntityLivingBase mob = e.getEntityLiving();
        if (!(mob instanceof IMob)) return;
        int[] beast = mob.getEntityData().getIntArray("sl_tiers");
        int tier;
        if (beast.length > 0) {
            tier = 0;
            for (int b : beast) tier = Math.max(tier, b);
            e.getDrops().add(new EntityItem(mob.world, mob.posX, mob.posY, mob.posZ, new ItemStack(ModItems.RINGS[tier])));
            return;
        }
        float h = mob.getMaxHealth();
        tier = tierFor(h);
        double chance = h >= 200 ? 1.0 : 0.05;
        if (mob.world.rand.nextDouble() < chance) {
            e.getDrops().add(new EntityItem(mob.world, mob.posX, mob.posY, mob.posZ, new ItemStack(ModItems.RINGS[tier])));
        }
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone e) {
        SoulData.tag(e.getEntityPlayer()).merge(SoulData.tag(e.getOriginal()));
    }

    @SubscribeEvent
    public static void login(PlayerLoggedInEvent e) {
        EntityPlayerMP p = (EntityPlayerMP) e.player;
        SoulData.applyBonuses(p);
        SoulData.sync(p);
        SoulData.syncVisual(p);
    }

    @SubscribeEvent
    public static void respawn(PlayerRespawnEvent e) {
        EntityPlayerMP p = (EntityPlayerMP) e.player;
        SoulData.applyBonuses(p);
        p.setHealth(p.getMaxHealth());
        SoulData.sync(p);
        SoulData.syncVisual(p);
    }
}
