package com.soulland.mod;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

/** วงแหวนวิญญาณแบบวงเวทบนพื้น (เรียงซ้อนเป็นวงรัศมีขยายออก) + โมเดลวิญญาณยุทธ์ */
@Mod.EventBusSubscriber(value = Side.CLIENT, modid = SoulLand.MODID)
public class SoulRender {
    // ขาว เหลือง ม่วง ดำ แดง
    private static final float[][] BODY = {{0.92F, 0.92F, 0.96F}, {1F, 0.82F, 0.15F}, {0.55F, 0.15F, 0.8F}, {0.13F, 0.13F, 0.15F}, {0.85F, 0.05F, 0.05F}};
    private static final float[][] RUNE = {{0.35F, 0.35F, 0.5F}, {0.5F, 0.3F, 0F}, {0.95F, 0.7F, 1F}, {0.9F, 0.15F, 0.2F}, {0.1F, 0F, 0F}};
    private static final float[][] GLOW = {{1F, 1F, 1F}, {1F, 0.8F, 0.2F}, {0.8F, 0.3F, 1F}, {0.7F, 0F, 0.2F}, {1F, 0.1F, 0.1F}};
    private static final float[] WOOD = {0.45F, 0.28F, 0.12F};
    private static final float[] STEEL = {0.62F, 0.66F, 0.78F};
    private static final float[] GLOW_BLUE = {0.3F, 0.6F, 1F};
    private static final float[] GRASS_BASE = {0.1F, 0.35F, 0.9F};
    private static final float[] GRASS_TIP = {0.75F, 0.92F, 1F};

    // ---------- ผู้เล่น ----------
    @SubscribeEvent
    public static void render(RenderPlayerEvent.Post e) {
        EntityPlayer p = e.getEntityPlayer();
        ClientState.Visual v = ClientState.visuals.get(p.getUniqueID());
        if (v == null || !v.released || v.soul == 0) return;

        float pt = e.getPartialRenderTick();
        float t = p.ticksExisted + pt;
        float yaw = p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt;

        begin(e.getX(), e.getY(), e.getZ());
        for (int pass = 0; pass < 2; pass++) {
            boolean glow = pass == 1;
            blend(glow);
            circles(v.tiers, 0.8F, 0.34F, t, glow);
            GlStateManager.pushMatrix();
            GlStateManager.rotate(-yaw, 0, 1, 0);
            if ((v.soul & 2) != 0) drawGrass(t, glow);
            if ((v.soul & 1) != 0) drawHammer(t, glow);
            GlStateManager.popMatrix();
        }
        end();
    }

    // ---------- สัตว์วิญญาณ (มอนสเตอร์ที่มีวงแหวน) ----------
    @SuppressWarnings("rawtypes")
    @SubscribeEvent
    public static void mob(RenderLivingEvent.Post e) {
        EntityLivingBase en = e.getEntity();
        if (en instanceof EntityPlayer) return;
        int[] tiers = ClientState.mobRings.get(en.getEntityId());
        if (tiers == null || tiers.length == 0) return;
        float t = en.ticksExisted + Minecraft.getMinecraft().getRenderPartialTicks();
        begin(e.getX(), e.getY(), e.getZ());
        for (int pass = 0; pass < 2; pass++) {
            boolean glow = pass == 1;
            blend(glow);
            circles(tiers, 0.35F + en.width * 0.7F, 0.28F, t, glow);
        }
        end();
    }

    // ---------- เปลวไฟสีม่วงรอบตัวผู้ที่ปล่อยวิญญาณ ----------
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null || mc.isGamePaused()) return;
        for (EntityPlayer p : mc.world.playerEntities) {
            ClientState.Visual v = ClientState.visuals.get(p.getUniqueID());
            if (v == null || !v.released || v.soul == 0) continue;
            for (int i = 0; i < 3; i++) {
                mc.world.spawnParticle(EnumParticleTypes.SPELL_WITCH,
                        p.posX + (mc.world.rand.nextDouble() - 0.5) * 0.9, p.posY + mc.world.rand.nextDouble() * 1.9,
                        p.posZ + (mc.world.rand.nextDouble() - 0.5) * 0.9, 0.0, 0.05, 0.0);
            }
        }
    }

    // ---------- สถานะ GL ----------
    private static void begin(double x, double y, double z) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
    }

    private static void blend(boolean glow) {
        if (glow) {
            GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            GlStateManager.depthMask(false);
        } else {
            GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
            GlStateManager.depthMask(true);
        }
    }

    private static void end() {
        GlStateManager.depthMask(true);
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.enableTexture2D();
        GlStateManager.enableLighting();
        GlStateManager.enableCull();
        GlStateManager.color(1F, 1F, 1F, 1F);
        GlStateManager.popMatrix();
    }

    // ---------- วงเวทวงแหวนวิญญาณ ----------
    private static void circles(int[] tiers, float base, float step, float t, boolean glow) {
        int n = tiers.length;
        for (int i = 0; i < n; i++) {
            int tier = Math.max(0, Math.min(4, tiers[i]));
            float r = base + step * i;
            float y = 0.025F + i * 0.004F;
            float rot = t * 0.012F * (i % 2 == 0 ? 1 : -1);
            if (glow) {
                flatRing(r - 0.2F, r + 0.2F, y + 0.003F, GLOW[tier], 0.16F);
                if (i == n - 1) {
                    flatRing(r + 0.2F, r + 0.45F, y, GLOW[tier], 0.11F);
                    flatRing(r + 0.45F, r + 0.75F, y, GLOW[tier], 0.06F);
                    flatRing(r + 0.75F, r + 1.1F, y, GLOW[tier], 0.03F);
                }
            } else {
                flatRing(r - 0.13F, r + 0.13F, y, BODY[tier], 0.9F);
                flatRing(r - 0.14F, r - 0.118F, y + 0.001F, RUNE[tier], 1F);
                flatRing(r + 0.118F, r + 0.14F, y + 0.001F, RUNE[tier], 1F);
                int cnt = 10 + i * 2;
                for (int k = 0; k < cnt; k++) glyph(r, rot + k * 2 * (float) Math.PI / cnt, y + 0.002F, RUNE[tier], k);
            }
        }
    }

    private static void flatRing(float rIn, float rOut, float y, float[] c, float a) {
        Tessellator ts = Tessellator.getInstance();
        BufferBuilder b = ts.getBuffer();
        b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        int n = 48;
        for (int i = 0; i < n; i++) {
            double a0 = i * 2 * Math.PI / n, a1 = (i + 1) * 2 * Math.PI / n;
            vtx(b, rIn * Math.cos(a0), y, rIn * Math.sin(a0), c, a);
            vtx(b, rOut * Math.cos(a0), y, rOut * Math.sin(a0), c, a);
            vtx(b, rOut * Math.cos(a1), y, rOut * Math.sin(a1), c, a);
            vtx(b, rIn * Math.cos(a1), y, rIn * Math.sin(a1), c, a);
        }
        ts.draw();
    }

    /** ลายอักขระ (รูปกากบาท) บนวงเวท */
    private static void glyph(float r, float ang, float y, float[] c, int k) {
        Tessellator ts = Tessellator.getInstance();
        BufferBuilder b = ts.getBuffer();
        b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        polar(b, ang, r - 0.085F, r + 0.085F, -0.012F, 0.012F, y, c);
        polar(b, ang, r - 0.02F, r + 0.02F, -0.06F, 0.06F, y, c);
        if (k % 3 == 0) polar(b, ang, r + 0.045F, r + 0.075F, -0.035F, 0.035F, y, c);
        if (k % 2 == 1) polar(b, ang, r - 0.075F, r - 0.045F, -0.03F, 0.03F, y, c);
        ts.draw();
    }

    private static void polar(BufferBuilder b, float ang, float r1, float r2, float t1, float t2, float y, float[] c) {
        double ca = Math.cos(ang), sa = Math.sin(ang);
        vtx(b, ca * r1 - sa * t1, y, sa * r1 + ca * t1, c, 1F);
        vtx(b, ca * r2 - sa * t1, y, sa * r2 + ca * t1, c, 1F);
        vtx(b, ca * r2 - sa * t2, y, sa * r2 + ca * t2, c, 1F);
        vtx(b, ca * r1 - sa * t2, y, sa * r1 + ca * t2, c, 1F);
    }

    // ---------- ค้อนฮ่าวเทียน ----------
    private static void drawHammer(float t, boolean glow) {
        GlStateManager.pushMatrix();
        GlStateManager.translate(-0.9F, 1.35F + 0.06F * (float) Math.sin(t * 0.07), -0.1F);
        GlStateManager.rotate(t * 1.5F, 0, 1, 0);
        GlStateManager.rotate(20F, 0, 0, 1);
        GlStateManager.scale(0.9F, 0.9F, 0.9F);
        if (glow) {
            box(-0.09, -0.65, -0.09, 0.09, 0.62, 0.09, GLOW_BLUE, 0.25F);
            box(-0.33, 0.30, -0.23, 0.33, 0.76, 0.23, GLOW_BLUE, 0.3F);
        } else {
            box(-0.04, -0.6, -0.04, 0.04, 0.6, 0.04, WOOD, 1F);
            box(-0.28, 0.35, -0.18, 0.28, 0.72, 0.18, STEEL, 1F);
            box(-0.30, 0.50, -0.20, 0.30, 0.56, 0.20, GLOW_BLUE, 1F);
            box(-0.06, -0.66, -0.06, 0.06, -0.55, 0.06, STEEL, 1F);
        }
        GlStateManager.popMatrix();
    }

    // ---------- หญ้าสีเงินคราม ----------
    private static void drawGrass(float t, boolean glow) {
        int count = 14;
        for (int k = 0; k < count; k++) {
            double a = k * 2 * Math.PI / count + t * 0.01;
            double rad = 0.4 + 0.3 * ((k * 37) % 5) / 5.0;
            float h = 0.55F + 0.55F * ((k * 53) % 7) / 7F;
            float tilt = 12F + 10F * (float) Math.sin(t * 0.08 + k);
            GlStateManager.pushMatrix();
            GlStateManager.translate(Math.cos(a) * rad, 0.03, Math.sin(a) * rad);
            GlStateManager.rotate((float) -Math.toDegrees(a), 0, 1, 0);
            GlStateManager.rotate(-tilt, 0, 0, 1);
            if (glow) {
                box(-0.06, 0, -0.06, 0.06, h, 0.06, GRASS_TIP, 0.18F);
            } else {
                box(-0.025, 0, -0.025, 0.025, h * 0.5F, 0.025, GRASS_BASE, 0.9F);
                box(-0.015, h * 0.5F, -0.015, 0.015, h, 0.015, GRASS_TIP, 0.95F);
            }
            GlStateManager.popMatrix();
        }
    }

    // ---------- ตัวช่วยวาด ----------
    private static void vtx(BufferBuilder b, double x, double y, double z, float[] c, float a) {
        b.pos(x, y, z).color(c[0], c[1], c[2], a).endVertex();
    }

    private static void box(double x1, double y1, double z1, double x2, double y2, double z2, float[] c, float a) {
        Tessellator ts = Tessellator.getInstance();
        BufferBuilder b = ts.getBuffer();
        b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        vtx(b, x1, y1, z1, c, a); vtx(b, x2, y1, z1, c, a); vtx(b, x2, y1, z2, c, a); vtx(b, x1, y1, z2, c, a);
        vtx(b, x1, y2, z1, c, a); vtx(b, x1, y2, z2, c, a); vtx(b, x2, y2, z2, c, a); vtx(b, x2, y2, z1, c, a);
        vtx(b, x1, y1, z1, c, a); vtx(b, x1, y2, z1, c, a); vtx(b, x2, y2, z1, c, a); vtx(b, x2, y1, z1, c, a);
        vtx(b, x1, y1, z2, c, a); vtx(b, x2, y1, z2, c, a); vtx(b, x2, y2, z2, c, a); vtx(b, x1, y2, z2, c, a);
        vtx(b, x1, y1, z1, c, a); vtx(b, x1, y1, z2, c, a); vtx(b, x1, y2, z2, c, a); vtx(b, x1, y2, z1, c, a);
        vtx(b, x2, y1, z1, c, a); vtx(b, x2, y2, z1, c, a); vtx(b, x2, y2, z2, c, a); vtx(b, x2, y1, z2, c, a);
        ts.draw();
    }
}
