package com.soulland.mod;

import java.util.List;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.WorldServer;

public class SoulSkills {
    public static final int HAMMER = 1, GRASS = 2;

    public static final class Skill {
        public final String key;
        public final int mask, ring, cost;
        Skill(String key, int mask, int ring, int cost) { this.key = key; this.mask = mask; this.ring = ring; this.cost = cost; }
    }

    /** ทักษะวิญญาณที่ N = ปลดล็อกด้วยวงแหวนวงที่ N */
    public static final Skill[] ALL = {
        new Skill("entangle", GRASS, 1, 10), new Skill("smash", HAMMER, 1, 15),
        new Skill("heal", GRASS, 2, 20),     new Skill("rage", HAMMER, 2, 20),
        new Skill("poison", GRASS, 3, 25),   new Skill("quake", HAMMER, 3, 30),
        new Skill("whip", GRASS, 4, 25),     new Skill("leap", HAMMER, 4, 35),
        new Skill("domain", GRASS, 5, 60),   new Skill("wrath", HAMMER, 5, 60),
        new Skill("storm", GRASS, 6, 70),    new Skill("thunder", HAMMER, 6, 70),
        new Skill("lock", GRASS, 7, 80),     new Skill("gravity", HAMMER, 7, 80),
        new Skill("rebirth", GRASS, 8, 100), new Skill("titan", HAMMER, 8, 100),
        new Skill("emperor", GRASS, 9, 150), new Skill("judgement", HAMMER, 9, 150)
    };

    public static boolean available(int soul, int rings, int idx) {
        if (idx < 0 || idx >= ALL.length) return false;
        Skill s = ALL[idx];
        return (soul & s.mask) != 0 && rings >= s.ring;
    }

    public static int next(int soul, int rings, int from) {
        for (int i = 1; i <= ALL.length; i++) {
            int j = (from + i + ALL.length) % ALL.length;
            if (available(soul, rings, j)) return j;
        }
        return -1;
    }

    private static void msg(EntityPlayerMP p, String key) {
        p.sendStatusMessage(new TextComponentTranslation(key), true);
    }

    public static void cycle(EntityPlayerMP p) {
        int n = next(SoulData.getSoul(p), SoulData.getRings(p), SoulData.getSelected(p));
        if (n < 0) { msg(p, "msg.soulland.noskill"); return; }
        SoulData.setSelected(p, n);
        SoulData.sync(p);
    }

    public static void toggleRelease(EntityPlayerMP p) {
        if (SoulData.getSoul(p) == 0) { msg(p, "msg.soulland.needawaken"); return; }
        NBTTagCompound t = SoulData.tag(p);
        boolean r = !t.getBoolean("released");
        t.setBoolean("released", r);
        WorldServer ws = (WorldServer) p.world;
        if (r) burst(ws, EnumParticleTypes.END_ROD, p.posX, p.posY + 1.0, p.posZ, 50, 0.6, 0.05);
        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0F, r ? 1.4F : 0.7F);
        SoulData.syncVisual(p);
    }

    // ---------- ตัวช่วยเอฟเฟกต์ ----------
    private static List<EntityLivingBase> nearby(EntityPlayerMP p, double r) {
        return p.world.getEntitiesWithinAABB(EntityLivingBase.class, p.getEntityBoundingBox().grow(r),
                e -> e != p && e instanceof IMob && e.isEntityAlive());
    }

    private static void hit(EntityPlayerMP p, EntityLivingBase e, float dmg) {
        e.hurtResistantTime = 0;
        e.attackEntityFrom(DamageSource.causePlayerDamage(p), dmg);
    }

    private static void push(EntityPlayerMP p, EntityLivingBase e, float str) {
        e.knockBack(p, str, p.posX - e.posX, p.posZ - e.posZ);
    }

    private static void burst(WorldServer ws, EnumParticleTypes t, double x, double y, double z, int n, double spread, double speed) {
        ws.spawnParticle(t, x, y, z, n, spread, spread, spread, speed);
    }

    private static void circle(WorldServer ws, EnumParticleTypes t, double x, double y, double z, double r, int n) {
        for (int i = 0; i < n; i++) {
            double a = i * 2 * Math.PI / n;
            ws.spawnParticle(t, x + Math.cos(a) * r, y, z + Math.sin(a) * r, 1, 0, 0, 0, 0.0);
        }
    }

    /** วงคลื่นกระจายหลายชั้นบนพื้น */
    private static void waves(WorldServer ws, EnumParticleTypes t, EntityPlayerMP p, double max, double step) {
        for (double r = step; r <= max; r += step) circle(ws, t, p.posX, p.posY + 0.15, p.posZ, r, (int) (r * 9) + 8);
    }

    private static void spiral(WorldServer ws, EnumParticleTypes t, EntityPlayerMP p, double r, double h, int n) {
        for (int i = 0; i < n; i++) {
            double a = i * 0.45;
            ws.spawnParticle(t, p.posX + Math.cos(a) * r, p.posY + h * i / n, p.posZ + Math.sin(a) * r, 1, 0, 0, 0, 0.0);
        }
    }

    private static void bolt(WorldServer ws, double x, double y, double z) {
        ws.addWeatherEffect(new EntityLightningBolt(ws, x, y, z, true));
    }

    private static void cleanse(EntityPlayerMP p) {
        p.removePotionEffect(MobEffects.POISON); p.removePotionEffect(MobEffects.WITHER);
        p.removePotionEffect(MobEffects.SLOWNESS); p.removePotionEffect(MobEffects.WEAKNESS);
        p.removePotionEffect(MobEffects.BLINDNESS); p.removePotionEffect(MobEffects.NAUSEA);
        p.removePotionEffect(MobEffects.HUNGER);
    }

    // ---------- ใช้สกิล ----------
    public static void cast(EntityPlayerMP p) {
        int soul = SoulData.getSoul(p), rings = SoulData.getRings(p), idx = SoulData.getSelected(p);
        if (soul == 0) return;
        if (!available(soul, rings, idx)) { msg(p, "msg.soulland.noskill"); return; }
        Skill s = ALL[idx];
        long now = p.world.getTotalWorldTime();
        NBTTagCompound t = SoulData.tag(p);
        if (now < t.getLong("cd")) return;
        int mana = SoulData.getMana(p);
        if (mana < s.cost) { msg(p, "msg.soulland.nomana"); return; }
        SoulData.setMana(p, mana - s.cost);
        if (!t.getBoolean("released")) { t.setBoolean("released", true); SoulData.syncVisual(p); }
        t.setLong("cd", now + 15);

        float mult = p.getHeldItemMainhand().getItem() == ModItems.HAMMER ? 1.5F : 1.0F;
        WorldServer ws = (WorldServer) p.world;
        double px = p.posX, py = p.posY, pz = p.posZ;
        ws.playSound(null, px, py, pz, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 0.8F, 0.6F);

        switch (s.key) {
            case "entangle":
                for (EntityLivingBase e : nearby(p, 6)) { hit(p, e, 4); e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 80, 4)); }
                waves(ws, EnumParticleTypes.VILLAGER_HAPPY, p, 6, 1.5);
                spiral(ws, EnumParticleTypes.VILLAGER_HAPPY, p, 1.0, 2.0, 40);
                break;
            case "smash":
                for (EntityLivingBase e : nearby(p, 4)) { hit(p, e, 8 * mult); push(p, e, 1.5F); }
                waves(ws, EnumParticleTypes.CLOUD, p, 4, 1.0);
                burst(ws, EnumParticleTypes.EXPLOSION_LARGE, px, py + 0.3, pz, 4, 1.2, 0.0);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.6F, 1.2F);
                break;
            case "heal":
                p.heal(6);
                p.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 160, 2));
                spiral(ws, EnumParticleTypes.HEART, p, 0.7, 2.0, 24);
                break;
            case "rage":
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 600, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 600, 0));
                spiral(ws, EnumParticleTypes.FLAME, p, 0.8, 2.2, 60);
                break;
            case "poison":
                for (EntityLivingBase e : nearby(p, 7)) { hit(p, e, 3); e.addPotionEffect(new PotionEffect(MobEffects.POISON, 100, 1)); }
                waves(ws, EnumParticleTypes.SLIME, p, 7, 1.75);
                break;
            case "quake":
                for (EntityLivingBase e : nearby(p, 6)) {
                    hit(p, e, 14 * mult);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 60, 1));
                    e.motionY = 0.6; e.velocityChanged = true;
                }
                waves(ws, EnumParticleTypes.SMOKE_LARGE, p, 6, 1.0);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.8F, 0.7F);
                break;
            case "whip": {
                Vec3d look = p.getLookVec();
                for (EntityLivingBase e : nearby(p, 10)) {
                    Vec3d to = new Vec3d(e.posX - px, e.posY + e.height / 2 - (py + p.getEyeHeight()), e.posZ - pz);
                    if (to.length() < 10 && to.normalize().dotProduct(look) > 0.92) hit(p, e, 14);
                }
                for (int i = 1; i <= 20; i++)
                    ws.spawnParticle(EnumParticleTypes.CRIT_MAGIC, px + look.x * i * 0.5, py + p.getEyeHeight() + look.y * i * 0.5,
                            pz + look.z * i * 0.5, 3, 0.1, 0.1, 0.1, 0.0);
                break;
            }
            case "leap": {
                Vec3d look = p.getLookVec();
                p.motionX = look.x * 1.4; p.motionY = 0.9; p.motionZ = look.z * 1.4;
                p.velocityChanged = true;
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 100, 4));
                waves(ws, EnumParticleTypes.CLOUD, p, 3, 1.0);
                break;
            }
            case "domain":
                for (EntityLivingBase e : nearby(p, 10)) {
                    hit(p, e, 5);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 200, 1));
                    e.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 200, 1));
                }
                p.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 200, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 200, 0));
                waves(ws, EnumParticleTypes.VILLAGER_HAPPY, p, 10, 2.0);
                spiral(ws, EnumParticleTypes.VILLAGER_HAPPY, p, 1.5, 3.0, 80);
                break;
            case "wrath":
                for (EntityLivingBase e : nearby(p, 8)) { hit(p, e, 25 * mult); push(p, e, 2.0F); }
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 200, 2));
                waves(ws, EnumParticleTypes.FLAME, p, 8, 2.0);
                burst(ws, EnumParticleTypes.EXPLOSION_HUGE, px, py + 0.5, pz, 3, 2.0, 0.0);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0F, 0.6F);
                break;
            case "storm":
                for (EntityLivingBase e : nearby(p, 8)) {
                    hit(p, e, 18);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 60, 2));
                    e.motionY = 0.35; e.velocityChanged = true;
                }
                spiral(ws, EnumParticleTypes.VILLAGER_HAPPY, p, 2.0, 4.0, 90);
                spiral(ws, EnumParticleTypes.CRIT_MAGIC, p, 3.0, 4.0, 90);
                waves(ws, EnumParticleTypes.SLIME, p, 8, 2.0);
                break;
            case "thunder": {
                List<EntityLivingBase> l = nearby(p, 14);
                l.sort((a, b) -> Double.compare(a.getDistanceSq(p), b.getDistanceSq(p)));
                int c = 0;
                for (EntityLivingBase e : l) {
                    if (c++ >= 6) break;
                    bolt(ws, e.posX, e.posY, e.posZ);
                    hit(p, e, 22 * mult);
                    burst(ws, EnumParticleTypes.FLAME, e.posX, e.posY + 1, e.posZ, 30, 0.4, 0.05);
                }
                waves(ws, EnumParticleTypes.CRIT_MAGIC, p, 6, 2.0);
                break;
            }
            case "lock":
                for (EntityLivingBase e : nearby(p, 10)) {
                    hit(p, e, 10);
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 100, 6));
                    e.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 100, 2));
                    e.addPotionEffect(new PotionEffect(MobEffects.GLOWING, 100, 0));
                    burst(ws, EnumParticleTypes.SPELL_WITCH, e.posX, e.posY + 1, e.posZ, 20, 0.4, 0.05);
                }
                waves(ws, EnumParticleTypes.SPELL_WITCH, p, 10, 2.0);
                break;
            case "gravity":
                for (EntityLivingBase e : nearby(p, 10)) {
                    hit(p, e, 8 * mult);
                    Vec3d d = new Vec3d(px - e.posX, py - e.posY, pz - e.posZ).normalize();
                    e.motionX += d.x * 1.2; e.motionY += d.y * 0.5 + 0.2; e.motionZ += d.z * 1.2;
                    e.velocityChanged = true;
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 60, 2));
                }
                spiral(ws, EnumParticleTypes.PORTAL, p, 2.5, 3.0, 100);
                waves(ws, EnumParticleTypes.PORTAL, p, 10, 2.5);
                break;
            case "rebirth":
                p.setHealth(p.getMaxHealth());
                p.addPotionEffect(new PotionEffect(MobEffects.ABSORPTION, 600, 3));
                p.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 200, 3));
                cleanse(p);
                spiral(ws, EnumParticleTypes.HEART, p, 1.0, 2.5, 50);
                burst(ws, EnumParticleTypes.VILLAGER_HAPPY, px, py + 1, pz, 60, 1.0, 0.1);
                break;
            case "titan":
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 400, 3));
                p.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 400, 2));
                p.addPotionEffect(new PotionEffect(MobEffects.ABSORPTION, 400, 4));
                for (EntityLivingBase e : nearby(p, 6)) { hit(p, e, 20 * mult); push(p, e, 2.0F); }
                spiral(ws, EnumParticleTypes.FLAME, p, 1.2, 3.5, 100);
                waves(ws, EnumParticleTypes.CLOUD, p, 6, 1.5);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0F, 0.5F);
                break;
            case "emperor": {
                List<EntityLivingBase> l = nearby(p, 12);
                int c = 0;
                for (EntityLivingBase e : l) {
                    hit(p, e, 40);
                    e.addPotionEffect(new PotionEffect(MobEffects.POISON, 200, 2));
                    e.addPotionEffect(new PotionEffect(MobEffects.WITHER, 100, 0));
                    e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 100, 1));
                    if (c++ < 4) bolt(ws, e.posX, e.posY, e.posZ);
                }
                p.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 300, 2));
                p.addPotionEffect(new PotionEffect(MobEffects.SPEED, 300, 1));
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 300, 0));
                waves(ws, EnumParticleTypes.SPELL_WITCH, p, 12, 2.0);
                waves(ws, EnumParticleTypes.VILLAGER_HAPPY, p, 11, 3.0);
                spiral(ws, EnumParticleTypes.VILLAGER_HAPPY, p, 2.0, 5.0, 120);
                break;
            }
            case "judgement": {
                List<EntityLivingBase> l = nearby(p, 14);
                int c = 0;
                for (EntityLivingBase e : l) {
                    hit(p, e, 60 * mult);
                    push(p, e, 2.5F);
                    if (c++ < 8) bolt(ws, e.posX, e.posY, e.posZ);
                }
                p.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 200, 3));
                waves(ws, EnumParticleTypes.FLAME, p, 14, 2.0);
                burst(ws, EnumParticleTypes.EXPLOSION_HUGE, px, py + 0.5, pz, 5, 3.0, 0.0);
                spiral(ws, EnumParticleTypes.FLAME, p, 2.0, 6.0, 120);
                ws.playSound(null, px, py, pz, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.2F, 0.5F);
                break;
            }
            default: break;
        }
        SoulData.sync(p);
    }
}
